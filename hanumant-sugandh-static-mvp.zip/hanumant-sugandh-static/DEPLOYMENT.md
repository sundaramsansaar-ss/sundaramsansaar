# Deploying the static site

Run `npm install` and `npm run build`. Upload the generated `dist/` directory to any static hosting provider.

For SPA routing, configure the host to serve `index.html` for unknown routes. If you prefer a no-config static host, use hash routing or add the host's SPA fallback rule.
