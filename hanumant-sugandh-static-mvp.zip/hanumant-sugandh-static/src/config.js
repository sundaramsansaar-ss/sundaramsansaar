// Replace this number with the seller's WhatsApp number in international format.
// India example: 919876543210 (no +, spaces, or leading 0).
export const WHATSAPP_NUMBER = "919876543210";

export const BRAND = {
  name: "Hanumant Sugandh",
  tagline: "Fragrance for a Better Life",
  whatsappNumber: WHATSAPP_NUMBER,
};
