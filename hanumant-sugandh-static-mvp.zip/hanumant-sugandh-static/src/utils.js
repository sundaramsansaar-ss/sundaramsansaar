export const money = (value) => `₹${Number(value).toLocaleString("en-IN")}`;

export const discount = (price, mrp) =>
  mrp > price ? Math.round(((mrp - price) / mrp) * 100) : 0;

export const getStoredCart = () => {
  try {
    return JSON.parse(localStorage.getItem("hanumant_cart") || "[]");
  } catch {
    return [];
  }
};

export const saveCart = (cart) => {
  localStorage.setItem("hanumant_cart", JSON.stringify(cart));
};

export const buildWhatsAppMessage = ({ cart, products, name, phone, note }) => {
  const lines = cart.map((item, index) => {
    const p = products.find((product) => product.id === item.productId);
    if (!p) return "";
    const subtotal = p.price * item.quantity;
    return `${index + 1}. ${p.name} (${p.unit})\n   Qty: ${item.quantity} × ${money(p.price)} = ${money(subtotal)}`;
  }).filter(Boolean);

  const total = cart.reduce((sum, item) => {
    const p = products.find((product) => product.id === item.productId);
    return sum + (p ? p.price * item.quantity : 0);
  }, 0);

  return [
    "🙏 Namaste Hanumant Sugandh,",
    "",
    "I would like to enquire about the following products:",
    "",
    ...lines,
    "",
    `Estimated total: ${money(total)}`,
    "",
    `Name: ${name || "-"}`,
    `Mobile: ${phone || "-"}`,
    `Message: ${note || "Please confirm availability and delivery details."}`,
    "",
    "Thank you.",
  ].join("\n");
};
