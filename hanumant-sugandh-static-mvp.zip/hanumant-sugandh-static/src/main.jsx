import React, { createContext, useContext, useEffect, useMemo, useState } from "react";
import ReactDOM from "react-dom/client";
import { BrowserRouter, Link, Route, Routes, useLocation, useNavigate, useParams } from "react-router-dom";
import {
  ArrowRight, ChevronDown, ChevronLeft, ChevronRight, CircleHelp, Flame, Heart, Home,
  Info, Menu, MessageCircle, Minus, Package, Plus, Search, ShoppingBag, Sparkles,
  Star, Trash2, X, Check, Phone, Send
} from "lucide-react";
import { categories, products, offers } from "./data";
import { BRAND, WHATSAPP_NUMBER } from "./config";
import { buildWhatsAppMessage, discount, getStoredCart, money, saveCart } from "./utils";
import "./styles.css";

const CartContext = createContext(null);

function CartProvider({ children }) {
  const [cart, setCart] = useState(getStoredCart);

  useEffect(() => saveCart(cart), [cart]);

  const addToCart = (productId, quantity = 1) => {
    setCart((current) => {
      const found = current.find((x) => x.productId === productId);
      if (found) return current.map((x) => x.productId === productId ? { ...x, quantity: x.quantity + quantity } : x);
      return [...current, { productId, quantity }];
    });
  };

  const updateQuantity = (productId, quantity) => {
    setCart((current) =>
      quantity <= 0 ? current.filter((x) => x.productId !== productId)
        : current.map((x) => x.productId === productId ? { ...x, quantity } : x)
    );
  };

  const remove = (productId) => setCart((current) => current.filter((x) => x.productId !== productId));
  const clear = () => setCart([]);

  const count = cart.reduce((s, x) => s + x.quantity, 0);
  const total = cart.reduce((s, x) => {
    const p = products.find((product) => product.id === x.productId);
    return s + (p ? p.price * x.quantity : 0);
  }, 0);

  const value = useMemo(() => ({ cart, addToCart, updateQuantity, remove, clear, count, total }), [cart, count, total]);
  return <CartContext.Provider value={value}>{children}</CartContext.Provider>;
}

const useCart = () => useContext(CartContext);

function Header({ onCart }) {
  const [menu, setMenu] = useState(false);
  const [query, setQuery] = useState("");
  const navigate = useNavigate();
  const { count } = useCart();

  const submitSearch = (e) => {
    e.preventDefault();
    if (query.trim()) navigate(`/search?q=${encodeURIComponent(query.trim())}`);
  };

  return (
    <header className="site-header">
      <div className="announcement">Pure Fragrance • Divine Blessings • A Peaceful Home</div>
      <div className="header-main container">
        <button className="mobile-menu" onClick={() => setMenu(!menu)} aria-label="Menu"><Menu size={22}/></button>
        <Link to="/" className="brand">
          <img src="/assets/logo-en.jpg" alt="Hanumant Sugandh logo" />
        </Link>
        <form className="search" onSubmit={submitSearch}>
          <Search size={19}/>
          <input value={query} onChange={(e) => setQuery(e.target.value)} placeholder="Search dhoop, kapoor, agarbatti..." />
          <button type="submit">Search</button>
        </form>
        <nav className={`nav ${menu ? "open" : ""}`}>
          <Link to="/" onClick={() => setMenu(false)}><Home size={17}/> Home</Link>
          <Link to="/categories" onClick={() => setMenu(false)}><Sparkles size={17}/> Categories</Link>
          <Link to="/offers" onClick={() => setMenu(false)}><Star size={17}/> Offers</Link>
          <Link to="/about" onClick={() => setMenu(false)}><Info size={17}/> About</Link>
        </nav>
        <button className="cart-button" onClick={onCart} aria-label="Open cart">
          <ShoppingBag size={21}/>
          <span>Cart</span>
          {count > 0 && <b>{count}</b>}
        </button>
      </div>
    </header>
  );
}

function Footer() {
  return (
    <footer className="footer">
      <div className="container footer-grid">
        <div>
          <img className="footer-logo" src="/assets/logo-en.jpg" alt="Hanumant Sugandh"/>
          <p>Fragrance for a Better Life.</p>
          <p className="muted">Premium dhoop, kapoor and devotional fragrances for a peaceful home.</p>
        </div>
        <div>
          <h4>Explore</h4>
          <Link to="/categories">Categories</Link>
          <Link to="/offers">Offers</Link>
          <Link to="/about">About us</Link>
        </div>
        <div>
          <h4>Purchase</h4>
          <p>Build your cart and send the enquiry directly to us on WhatsApp.</p>
          <a className="whatsapp-link" href={`https://wa.me/${WHATSAPP_NUMBER}`} target="_blank" rel="noreferrer"><MessageCircle size={17}/> WhatsApp us</a>
        </div>
      </div>
      <div className="footer-bottom">© {new Date().getFullYear()} Hanumant Sugandh. All rights reserved.</div>
    </footer>
  );
}

function Layout() {
  const [cartOpen, setCartOpen] = useState(false);
  return <>
    <Header onCart={() => setCartOpen(true)} />
    <main><Routes>
      <Route path="/" element={<HomePage onCart={() => setCartOpen(true)} />} />
      <Route path="/categories" element={<CategoriesPage />} />
      <Route path="/category/:slug" element={<CategoryPage onCart={() => setCartOpen(true)} />} />
      <Route path="/product/:id" element={<ProductPage onCart={() => setCartOpen(true)} />} />
      <Route path="/search" element={<SearchPage onCart={() => setCartOpen(true)} />} />
      <Route path="/cart" element={<CartPage />} />
      <Route path="/offers" element={<OffersPage onCart={() => setCartOpen(true)} />} />
      <Route path="/about" element={<AboutPage />} />
    </Routes></main>
    <Footer />
    <CartDrawer open={cartOpen} onClose={() => setCartOpen(false)} />
  </>;
}

function Hero() {
  const [slide, setSlide] = useState(0);
  const slides = [
    { title: "Pure Fragrance. Divine Blessings.", text: "Premium dhoop and devotional fragrances crafted for a peaceful home." },
    { title: "Bring a Sacred Fragrance Home.", text: "Discover coconut, mogra, gulab, jasmine and traditional sambhrani fragrances." },
  ];
  useEffect(() => {
    const id = setInterval(() => setSlide((s) => (s + 1) % slides.length), 6500);
    return () => clearInterval(id);
  }, []);
  const current = slides[slide];
  return <section className="hero">
    <img src="/assets/hero-products.jpg" alt="Hanumant Sugandh premium devotional products" />
    <div className="hero-overlay"></div>
    <button className="hero-arrow left" onClick={() => setSlide((slide - 1 + slides.length) % slides.length)}><ChevronLeft/></button>
    <button className="hero-arrow right" onClick={() => setSlide((slide + 1) % slides.length)}><ChevronRight/></button>
    <div className="container hero-content">
      <span className="eyebrow">PREMIUM DEVOTIONAL FRAGRANCE</span>
      <h1>{current.title}</h1>
      <p>{current.text}</p>
      <div className="hero-actions">
        <Link className="btn primary" to="/categories">Explore Products <ArrowRight size={18}/></Link>
        <Link className="btn light" to="/about">Our Story</Link>
      </div>
      <div className="trust-row">
        <span><Sparkles size={18}/> Premium blends</span>
        <span><Flame size={18}/> Long-lasting aroma</span>
        <span><Heart size={18}/> Made for devotion</span>
      </div>
    </div>
    <div className="dots">{slides.map((_, i) => <button key={i} className={i === slide ? "active" : ""} onClick={() => setSlide(i)} />)}</div>
  </section>;
}

function SectionHeading({ kicker, title, action }) {
  return <div className="section-heading">
    <div><span className="kicker">{kicker}</span><h2>{title}</h2></div>
    {action}
  </div>;
}

function CategoryCard({ category }) {
  return <Link to={`/category/${category.id}`} className="category-card">
    <div className="category-icon">{category.icon}</div>
    <div><h3>{category.name}</h3><p>{category.subtitle}</p></div>
    <ArrowRight size={18}/>
  </Link>;
}

function ProductCard({ product, onCart }) {
  const { addToCart } = useCart();
  return <article className="product-card">
    <Link to={`/product/${product.id}`} className="product-image-wrap">
      <img src={product.image} style={{objectPosition: product.imagePosition}} alt={product.name}/>
      <span className="badge">{product.badge}</span>
    </Link>
    <div className="product-info">
      <span className="product-category">{product.category} • {product.unit}</span>
      <Link to={`/product/${product.id}`}><h3>{product.name}</h3></Link>
      <p>{product.description}</p>
      <div className="price-row"><strong>{money(product.price)}</strong><del>{money(product.mrp)}</del><span>{discount(product.price, product.mrp)}% OFF</span></div>
      <button className="add-btn" onClick={() => { addToCart(product.id); onCart?.(); }}><ShoppingBag size={17}/> Add to cart</button>
    </div>
  </article>;
}

function HomePage() {
  return <div>
    <Hero />
    <section className="section container">
      <SectionHeading kicker="DISCOVER" title="Shop by Category" action={<Link className="text-link" to="/categories">View all <ArrowRight size={16}/></Link>} />
      <div className="category-grid">{categories.map((c) => <CategoryCard key={c.id} category={c}/>)}</div>
    </section>

    <section className="section tinted">
      <div className="container">
        <SectionHeading kicker="CURATED FOR YOU" title="Bestsellers" action={<Link className="text-link" to="/category/dhoop">View all <ArrowRight size={16}/></Link>} />
        <div className="product-grid">{products.slice(0, 6).map((p) => <ProductCard key={p.id} product={p}/>)}</div>
      </div>
    </section>

    <section className="story-strip container">
      <div className="story-copy">
        <span className="kicker">HANUMANT SUGANDH</span>
        <h2>Pure fragrance. Divine blessings.</h2>
        <p>Explore fragrances inspired by daily worship, meditation and the warmth of a peaceful Indian home.</p>
        <Link className="btn primary" to="/categories">Shop the collection <ArrowRight size={18}/></Link>
      </div>
      <img src="/assets/logo-hi.jpg" alt="Hanumant Sugandh Hindi brand mark"/>
    </section>

    <section className="offer-band">
      <div className="container offer-grid">{offers.map((o) => <div key={o.label}><strong>{o.label}</strong><span>{o.text}</span></div>)}</div>
    </section>
  </div>;
}

function CategoriesPage() {
  return <div className="page container">
    <div className="page-hero"><span className="kicker">COLLECTION</span><h1>Shop by Category</h1><p>Find the fragrance that fits your daily ritual.</p></div>
    <div className="category-grid large">{categories.map((c) => <CategoryCard key={c.id} category={c}/>)}</div>
  </div>;
}

function CategoryPage({ onCart }) {
  const { slug } = useParams();
  const category = categories.find((c) => c.id === slug);
  const [sort, setSort] = useState("featured");
  if (!category) return <NotFound />;
  let list = products.filter((p) => p.categoryId === slug);
  if (sort === "low") list = [...list].sort((a,b) => a.price-b.price);
  if (sort === "high") list = [...list].sort((a,b) => b.price-a.price);
  return <div className="page container">
    <div className="listing-head"><div><span className="kicker">CATEGORY</span><h1>{category.name}</h1><p>{category.subtitle}</p></div>
      <select value={sort} onChange={(e)=>setSort(e.target.value)}><option value="featured">Featured</option><option value="low">Price: Low to high</option><option value="high">Price: High to low</option></select>
    </div>
    <div className="product-grid">{list.map((p) => <ProductCard key={p.id} product={p} onCart={onCart}/>)}</div>
  </div>;
}

function ProductPage({ onCart }) {
  const { id } = useParams();
  const product = products.find((p) => p.id === id);
  const { addToCart } = useCart();
  const [qty, setQty] = useState(1);
  if (!product) return <NotFound />;
  return <div className="page container">
    <div className="product-detail">
      <div className="detail-image"><img src={product.image} style={{objectPosition: product.imagePosition}} alt={product.name}/></div>
      <div className="detail-copy">
        <span className="product-category">{product.category} • {product.unit}</span>
        <h1>{product.name}</h1>
        <div className="detail-rating"><span>★★★★★</span> Loved for everyday rituals</div>
        <div className="detail-price"><strong>{money(product.price)}</strong><del>{money(product.mrp)}</del><span>{discount(product.price, product.mrp)}% OFF</span></div>
        <p className="lead">{product.description}</p>
        <ul className="feature-list">{product.features.map((f)=><li key={f}><Check size={17}/>{f}</li>)}</ul>
        <div className="quantity"><span>Quantity</span><div><button onClick={()=>setQty(Math.max(1,qty-1))}><Minus size={16}/></button><b>{qty}</b><button onClick={()=>setQty(qty+1)}><Plus size={16}/></button></div></div>
        <div className="detail-actions">
          <button className="btn primary" onClick={()=>{addToCart(product.id, qty); onCart?.();}}><ShoppingBag size={18}/> Add to cart</button>
          <Link className="btn whatsapp" to="/cart"><MessageCircle size={18}/> Buy via WhatsApp</Link>
        </div>
        <div className="note"><Package size={18}/><span>Build a multi-product cart and send one enquiry on WhatsApp.</span></div>
      </div>
    </div>
    <section className="section related"><SectionHeading kicker="YOU MAY ALSO LIKE" title="More fragrances" /><div className="product-grid">{products.filter(p=>p.categoryId===product.categoryId && p.id!==product.id).slice(0,4).map(p=><ProductCard key={p.id} product={p} onCart={onCart}/>)}</div></section>
  </div>;
}

function SearchPage({ onCart }) {
  const params = new URLSearchParams(useLocation().search);
  const q = params.get("q") || "";
  const list = products.filter(p => `${p.name} ${p.category} ${p.description}`.toLowerCase().includes(q.toLowerCase()));
  return <div className="page container">
    <div className="page-hero"><span className="kicker">SEARCH</span><h1>Results for “{q}”</h1><p>{list.length} product{list.length===1?"":"s"} found.</p></div>
    {list.length ? <div className="product-grid">{list.map(p=><ProductCard key={p.id} product={p} onCart={onCart}/>)}</div> : <EmptyState text="No matching products found." />}
  </div>;
}

function OffersPage({ onCart }) {
  const list = products.filter(p => discount(p.price,p.mrp) >= 10);
  return <div className="page container">
    <div className="page-hero"><span className="kicker">SPECIAL</span><h1>Offers & Highlights</h1><p>Premium fragrances and value packs available for enquiry.</p></div>
    <div className="offer-cards">{offers.map(o=><div className="offer-card" key={o.label}><Sparkles/><strong>{o.label}</strong><p>{o.text}</p></div>)}</div>
    <div className="section compact"><SectionHeading kicker="SHOP OFFERS" title="Featured deals" /><div className="product-grid">{list.map(p=><ProductCard key={p.id} product={p} onCart={onCart}/>)}</div></div>
  </div>;
}

function AboutPage() {
  return <div className="page container">
    <div className="about-grid">
      <div><span className="kicker">OUR STORY</span><h1>Fragrance for a Better Life.</h1><p className="lead">Hanumant Sugandh brings devotional fragrance into everyday moments — from the first diya of the morning to a quiet evening of prayer and meditation.</p><p>Our collection focuses on premium dhoop, kapoor, agarbatti and puja essentials, presented with a simple experience that makes discovering your favourites easy.</p><a className="btn whatsapp" href={`https://wa.me/${WHATSAPP_NUMBER}`} target="_blank" rel="noreferrer"><MessageCircle size={18}/> Talk to us on WhatsApp</a></div>
      <div className="about-card"><img src="/assets/logo-hi.jpg" alt="Hanumant Sugandh"/><div><span>भक्ति की पवित्र सुगंध</span><strong>Pure Fragrance • Divine Blessings</strong></div></div>
    </div>
  </div>;
}

function CartDrawer({ open, onClose }) {
  const { cart, updateQuantity, remove, total } = useCart();
  if (!open) return null;
  return <div className="drawer-backdrop" onClick={onClose}>
    <aside className="cart-drawer" onClick={e=>e.stopPropagation()}>
      <div className="drawer-head"><div><span className="kicker">YOUR BAG</span><h2>Cart</h2></div><button onClick={onClose}><X/></button></div>
      <CartContents />
      {cart.length > 0 && <div className="drawer-bottom"><div><span>Estimated total</span><strong>{money(total)}</strong></div><Link to="/cart" className="btn primary" onClick={onClose}>Review & enquire <ArrowRight size={17}/></Link></div>}
    </aside>
  </div>;
}

function CartContents() {
  const { cart, updateQuantity, remove } = useCart();
  if (!cart.length) return <EmptyState text="Your cart is waiting for a little fragrance." />;
  return <div className="cart-items">{cart.map(item=>{
    const p=products.find(x=>x.id===item.productId); if(!p) return null;
    return <div className="cart-item" key={item.productId}>
      <img src={p.image} style={{objectPosition:p.imagePosition}} alt={p.name}/>
      <div><h3>{p.name}</h3><small>{p.unit}</small><strong>{money(p.price)}</strong><div className="mini-qty"><button onClick={()=>updateQuantity(p.id,item.quantity-1)}><Minus/></button><b>{item.quantity}</b><button onClick={()=>updateQuantity(p.id,item.quantity+1)}><Plus/></button><button className="remove" onClick={()=>remove(p.id)}><Trash2/></button></div></div>
    </div>
  })}</div>;
}

function CartPage() {
  const { cart, total, updateQuantity, remove } = useCart();
  const [form, setForm] = useState({name:"",phone:"",note:""});
  const [sent, setSent] = useState(false);
  const navigate = useNavigate();

  const send = (e) => {
    e.preventDefault();
    if (!form.name.trim() || !form.phone.trim()) return;
    const message = buildWhatsAppMessage({cart, products, ...form});
    if (!WHATSAPP_NUMBER || WHATSAPP_NUMBER.includes("XXXX")) {
      alert("Please set the seller WhatsApp number in src/config.js before using this button.");
      return;
    }
    window.open(`https://wa.me/${WHATSAPP_NUMBER}?text=${encodeURIComponent(message)}`, "_blank", "noopener,noreferrer");
    setSent(true);
  };

  if (!cart.length) return <div className="page container"><EmptyState text="Your cart is empty." action={<Link className="btn primary" to="/categories">Browse products</Link>}/></div>;

  return <div className="page container">
    <div className="page-hero small"><span className="kicker">PURCHASE ENQUIRY</span><h1>Your cart</h1><p>Products and quantities are automatically included in your WhatsApp enquiry.</p></div>
    <div className="checkout-grid">
      <div className="checkout-card"><h2>Selected products</h2>{cart.map(item=>{
        const p=products.find(x=>x.id===item.productId);
        return <div className="checkout-item" key={p.id}><img src={p.image} style={{objectPosition:p.imagePosition}} alt={p.name}/><div><h3>{p.name}</h3><small>{p.unit}</small><div className="checkout-controls"><div className="mini-qty"><button onClick={()=>updateQuantity(p.id,item.quantity-1)}><Minus/></button><b>{item.quantity}</b><button onClick={()=>updateQuantity(p.id,item.quantity+1)}><Plus/></button></div><button className="remove-text" onClick={()=>remove(p.id)}>Remove</button></div></div><strong>{money(p.price*item.quantity)}</strong></div>
      })}<div className="total-line"><span>Estimated total</span><strong>{money(total)}</strong></div></div>
      <form className="checkout-card enquiry-form" onSubmit={send}>
        <h2>Your details</h2><p className="muted">Only three simple fields. We'll send the complete cart to WhatsApp.</p>
        <label>Name *<input required value={form.name} onChange={e=>setForm({...form,name:e.target.value})} placeholder="Your name"/></label>
        <label>Mobile number *<input required type="tel" value={form.phone} onChange={e=>setForm({...form,phone:e.target.value})} placeholder="10-digit mobile number"/></label>
        <label>Message<textarea value={form.note} onChange={e=>setForm({...form,note:e.target.value})} placeholder="Any delivery or product request?"></textarea></label>
        <button className="btn whatsapp full" type="submit"><Send size={18}/> Send enquiry on WhatsApp</button>
        {sent && <div className="sent"><Check size={17}/> WhatsApp opened with your enquiry.</div>}
        <button type="button" className="back-link" onClick={()=>navigate("/categories")}>Continue shopping</button>
      </form>
    </div>
  </div>;
}

function EmptyState({text,action}) { return <div className="empty"><ShoppingBag size={38}/><h3>{text}</h3>{action}</div>; }
function NotFound() { return <div className="page container"><EmptyState text="We couldn't find that page." action={<Link className="btn primary" to="/">Back home</Link>}/></div>; }

function App() {
  return <CartProvider><Layout/></CartProvider>;
}

ReactDOM.createRoot(document.getElementById("root")).render(
  <React.StrictMode><BrowserRouter><App/></BrowserRouter></React.StrictMode>
);
