# Hanumant Sugandh — Static MVP

A fully static React/Vite storefront for Hanumant Sugandh, based on the supplied brand logos and product/banner artwork.

## MVP features

- Responsive homepage
- Brand-led hero section
- Product categories
- Product listing and sorting
- Product details
- Search
- Multi-product cart
- Cart persistence with `localStorage`
- Quantity controls
- Purchase enquiry form
- Automatic WhatsApp message containing products + quantities + customer details
- Offers and About pages
- No backend, database, authentication, payment gateway, or order API

## Run locally

Requirements: Node.js 18+.

```bash
npm install
npm run dev
```

Then open the local URL printed by Vite.

## Build

```bash
npm run build
npm run preview
```

## Configure WhatsApp

Open:

`src/config.js`

Change:

```js
export const WHATSAPP_NUMBER = "919876543210";
```

to the seller's real WhatsApp number in international format, without `+`, spaces, or dashes.

Example for an Indian number:

```js
export const WHATSAPP_NUMBER = "919812345678";
```

The cart stays in the customer's browser using `localStorage`. When the customer submits the enquiry, the site creates a WhatsApp click-to-chat URL containing the product names, units, quantities, estimated total, name, mobile number and message.

## Supplied assets

The project uses the uploaded Hanumant Sugandh logo and promotional artwork under:

`public/assets/`

Replace those files later with higher-resolution original brand assets if available.
